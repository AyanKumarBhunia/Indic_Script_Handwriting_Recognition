function [imgi ,mr ,mc] = plot_pnt(f,t) %wwwwwwwww

%% designed by Prasenjit. 

%wwwwwwwwwwwwwwwwwwwwwwwwww
% if size(f,3)==4
%     f=f(:,:,1:3);
% end;
% 
% f=~im2bw(f);
% 
% [rw cw]=find(f==1);
% f=f(min(rw):max(rw),min(cw):max(cw)); % trim image
% 
% f=padarray(f,[2 2]);  %% for letters which are touching the fisrst and last col of image
%  f=deskew(f);          %% size of the image changes in rotating it....
%wwwwwwwwwwwwwwwwwwwwwwwwww
global fg;
matra_row=hist_matra(f);
f3=bwmorph(f,'thin',3);

fg=bwmorph(f3,'skel',inf);

 fg=bwmorph(fg,'spur',5);
 fg=bwmorph(fg,'clean');
 fg=bwmorph(fg,'bridge');
imgi=fg;

 [cg mrkg]=corners(fg);

imgsk=zeros(size(f3,1),size(f3,2));
 for i=1:size(cg,1)
imgsk(cg(i,1),cg(i,2))=1;
end;

if nargin==1
    t=3.2;
end;

% imiso=bwdist(imgsk)<=t;
%  imiso=bwmorph(imiso,'shrink',inf);  %% for isotropic dilation
% 
%  [riso ciso]=find(imiso==1);

%%without isotropic dilation
[riso ciso]=find(imgsk==1);

for i=1:numel(riso)
     if fg(riso(i),ciso(i))==1
         continue;
     else
         r=riso(i);
         c=ciso(i);
         
         [r1 c1]=find(fg(r-1:r+1,c-1:c+1)==1);
       r1= r-2+r1; c1=c-2+c1;
         if numel(r1)==0
             [r1 c1]=find(fg(r-2:r+2,c-2:c+2)==1);
            r1= r-3+r1; c1=c-3+c1;
         end;
      
        if numel(r1)~=0
         riso(i)=r1(1);
         ciso(i)=c1(1);
        end;
        
     end;
  

 end;
   [ rciso,ia,ic ]=unique([riso ciso],'rows','stable');
 
   [pix_r pix_c]=find(fg==1);
   min_r=min(pix_r);
   max_r=max(pix_r);
%    n_rows=max_r-min_r;           %% matra detecting
%    lim=round(.7*n_rows);
%    
%  hist_mat=zeros(1,min_r+lim);
%    
%    for i=1:min_r+lim
%        hist_mat(i)=numel(find(fg(i,:)==1));
%    end;
  
% plot(hist_mat)
%  [m max_ind]=max(hist_mat);

% matra_row=hist_matra(fg);

  global winup;
  global windn;
   winup=matra_row-7;  %-12
     windn=matra_row+5;  % +5

    q=1;
    global pnt_mat;
    for k=1:size(rciso,1)
        if winup<=rciso(k,1) && rciso(k,1)<=windn
            pnt_mat(q,1)=rciso(k,1);
            pnt_mat(q,2)=rciso(k,2);
            q=q+1;
        end;
    end;
    pnt_mat=sortrows(pnt_mat,2);
    
    global tst_mat;
    global sz;
    global chk_mat;
    chk_mat= zeros(size(fg,1),size(fg,2));
      tst_mat= zeros(size(fg,1),size(fg,2));

    
    sz=size(fg,2);
    global j;
    for j=1:size(pnt_mat,1)
        rowp=pnt_mat(j,1);
        colp=pnt_mat(j,2);
%        display(rowp)
%        display(colp)
       
        getpath(rowp,colp);
    end;
    
    X=[1:size(fg,2)];

    [mr mc]=find(tst_mat==1);
    if isempty(mr) ==1
        mr=matra_row;      %% if win_dn is small and no matra curve found then [mr mc] is null,,chk for win_dn=5 on bw_61 img.
        mc=2;
    end;
    
    
    %%wwwwwwwwwwwwwwww
    
%     iq=1;
%        for ip=1:size(rciso,1)
%         if rciso(ip,1)<=windn && rciso(ip,1)>=winup
%         mupnt(iq,1)=rciso(ip,1);
%         mupnt(iq,2)=rciso(ip,2);
%         iq=iq+1;
%         end;
%        end;
    
    %%wwwwwwwwwwwwwwwww
    
%     figure, imshow(tst_mat)       %+++++++++++++++++
%  figure,imshow(fg)
% hold on
% % plot(mupnt(:,2)',mupnt(:,1)','squareg')
%  plot(rciso(:,2)',rciso(:,1)','squareg')
% hold on
% plot(X,min_r,X,max_r,X,matra_row,'-r',X,winup,'-y',X,windn,'-y')
% hold on
% plot(mc',mr','.b')                % +++++++++++++++++


    
    function []=getpath(row,col)
       global fg; 
       global chk_mat ;
        global tst_mat;
        global sz;
        global j;
        global pnt_mat;
        global winup;
        global windn;
        
        if col<1
            return;
        elseif col>sz
                return;
        elseif row>windn
                return;
        elseif row<winup
                return;
        elseif fg(row,col)==0
                return;
        elseif chk_mat(row,col)==1
                return;
        elseif tst_mat(row,col)==1
                return;
        elseif any(ismember(pnt_mat(j+1:end,:),[row col],'rows'))
           ind= find(chk_mat==1);    
            tst_mat(ind)=1;
            
                        return;
        else
                        
                        chk_mat(row,col)=1;
                        
                        getpath(row-1,col-1);
                        getpath(row-1,col);
                        getpath(row-1,col+1);
                        getpath(row,col-1);
                        getpath(row,col+1);
                        getpath(row+1,col-1);
                        getpath(row+1,col);
                        getpath(row+1,col+1);
                        
                        chk_mat(row,col)=0;
                        
        end;
        
        
                    
                    
    
    
    
 
