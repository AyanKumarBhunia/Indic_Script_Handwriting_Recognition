src='D:\Datasets\DATA\DATA\All_original';%Give SOURCE FOLDER NAME
targ='';%Give TARGET FOLDER NAME


s=strcat(src,'\*.tif');
D=dir(s);
E=0;
for i=1:numel(D)
    f=imread(strcat(src,'\',D(i).name));
    s=strcat('processing ',D(i).name,' ....');
    disp(s)
     try
      g=(busy(f)); 
      imwrite(g,strcat(targ,'\',D(i).name),'png');
     catch 
        s=strcat('ERROR !! CANT PROCESS ',D(i).name,' !!','CONTINUE EXECUTION....');
        disp(s)
        E=E+1;
      end  
    
end;
disp('PROCESSING COMPLETED SUCCESSFULLY');
disp(strcat('error(',num2str(E),')'))
 

