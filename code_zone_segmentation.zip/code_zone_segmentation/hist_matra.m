function matra_row=hist_matra(f)

% upper busy zone
%%

 [r c]=find(f==1);
wid=max(c)-min(c);
l_dist=round(.15*wid);  %% note the val of this estimated letter width

b_zoneimg=zeros(size(f));

for i=1:max(r)
    for j=1:size(f,2)
       jd=j+l_dist;
       if jd>size(f,2)
           jd=size(f,2);
       end;
        
        if f(i,j)==0
            continue;
        else
            ind=find(f(i,j+1:jd)==1);
            if numel(ind)==0
                continue;
            else
                b_zoneimg(i,j:j+ind(1)-1)=1;
            end;
        end;
    end;
end;

busy_hist_mat=zeros(1,size(f,1));
for i=1:size(b_zoneimg,1)
     busy_hist_mat(i)=numel(find(b_zoneimg(i,:)==1));
end;

% figure,imshow(b_zoneimg)   %% ++++
% title('upper busy zone')
%%

[m ind]=max(busy_hist_mat);
thr=0.3*m;
for i=ind:-1:1
if busy_hist_mat(i)<thr
y=i;
break;
end;
end;

   X=[1:size(f,2)];

% hold on
% plot(X,y);  %+++++++++


%%
%finding histogram matra


[pix_r pix_c]=find(f==1);
   min_r=min(pix_r);
   max_r=max(pix_r);
   n_rows=max_r-min_r;
   lim=round(.7*n_rows);
   
 hist_mat=zeros(1,min_r+lim);
   
   for i=1:min_r+lim
       hist_mat(i)=numel(find(f(i,:)==1));
   end;
   
   [m max_ind]=max(hist_mat);

if abs(max_ind-y)>10  % + - pixels range for estimated matra
matra_row=y;
else
matra_row=max_ind;
end;

   X=[1:size(f,2)];
 
% figure, imshow(f),hold on
%  plot(X,matra_row)      %+++++++
%  title('detected matra')
%   plot(hist_mat)