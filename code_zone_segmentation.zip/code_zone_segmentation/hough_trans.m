function lines = hough_trans(f,res,peaks)

[rw cw]=find(f==1);
let_wid=round(.20*(max(cw)-min(cw)));

[h theta p]=hough(f,'ThetaResolution',res);
pk=houghpeaks(h,peaks);
lines=houghlines(f,theta,p,pk,'Fillgap',let_wid,'MinLength',round((.5*size(f,2)))); %more arguments are possible in this func controlling merge lines min_dist lines threhld val..see book
