function img = deskew(f)

% if size(f,3)==4
%     f=f(:,:,1:3);
% end;
% 
% f=~im2bw(f);
% [rw cw]=find(f==1);
% f=f(min(rw):max(rw),min(cw):max(cw)); % trim image
% 
% f=padarray(f,[2 2]); 


f=bwmorph(f,'clean');
f=bwmorph(f,'bridge');
f=bwmorph(f,'majority');
img=f;
line=hough_trans(f,0.2,2);

% q=1;
% for i=1:numel(lin)
%     line(q)=lin(1,i);
%     q=q+1;
% end;

if numel(line)==0  %% if no sufficient line found;
return;
end;

% for j=1:numel(line)
%     dist=abs(line(1,j).point1(1)-line(1,j).point2(1));
%     if dist<(.5*size(f,2))
%         line(j)=[];
%     end;
% end;

totalpix=numel(find(f==1));
q=1;

for k=1:numel(line)
[x y]=bresenham(line(1,k).point1(1),line(1,k).point1(2),line(1,k).point2(1),line(1,k).point2(2));
wpix=0;

for i=1:numel(x)
    wpix=wpix+numel(find(f(1:y(i),x(i))==1));
end;
%  wpix
if wpix<(0.35*totalpix)   % note this threshold
   modf_line(1,q)=line(1,k);
   q=q+1;
end;

end;
% plot_hough(f,line);
% plot_hough(f,modf_line);

if  q==1          % numel(modf_line)==0  %% if no sufficient line found;
return;
elseif numel(modf_line)==1
    k=modf_line(1);
else
    
    if (90-abs(modf_line(1).theta))>=8
k=modf_line(2);
else
k=modf_line(1);
end;

end;


if (90-abs(k.theta))>=8
return
end;

ang=k.theta;

if ang<0
ang=90-abs(ang);
else
ang=ang-90;
end;

img=imrotate(f,ang);

