function [midimg]=sgmnt_top(f)
[fg ,mr ,mc]=plot_pnt(f);
d=[mr mc];
d=sortrows(d,1);

q=1;
for i=1:size(fg,2)
    [r c]=find(d(:,2)==i);
    
    if numel(c)==0 
       continue;
    else 
        upnt(q,1)=d(r(1),1) ;
        upnt(q,2)=d(r(1),2);
        q=q+1;
   
    end;
end;
 tmpimg=zeros(size(fg));

for j=1:q-1
    tmpimg(upnt(j,1),upnt(j,2))=1;
end;
%wwwwwwwww
% imshow(fg)
% hold on
% plot(upnt(:,2),upnt(:,1),'bo');
%% working fine 

upnt=sortrows(upnt,2);
[lin_c lin_r]=bresenham(1,upnt(1,1),upnt(1,2),upnt(1,1));       %% remember x1 y1 to x2 y2

lin_mat=[lin_c lin_r];

for i=1:(size(upnt,1)-1)
    if (upnt(i+1,2)-upnt(i,2)==1)&&(upnt(i+1,1)-upnt(i,1)==1)
        continue;
    else
        [lc lr]=bresenham(upnt(i,2),upnt(i,1),upnt(i+1,2),upnt(i+1,1));
        l_mat=[lc lr];
        lin_mat=vertcat(lin_mat,l_mat);
    end;
end;

    [lc lr]=bresenham(upnt(end,2),upnt(end,1),size(fg,2),upnt(end,1));
l_mat=[lc lr];
        lin_mat=vertcat(lin_mat,l_mat);

      X=[1:size(fg,2)]; 
       
% figure,imshow(fg)                 % +++++++++++
% hold on
% % plot(mupnt(:,2)',mupnt(:,1)','sr')
% hold on
% % plot(X,53,'.r',X,39,'.y',X,65,'.y')
% hold on
% plot(upnt(:,2),upnt(:,1),'.b')
% hold on
% plot(lin_mat(:,1),lin_mat(:,2),'.g')    % ++++++++++++

%% woking fine 
 lin_mat_swp=[lin_mat(:,2) lin_mat(:,1)]; % change x y to row col
 
lin_mat_swp=vertcat(lin_mat_swp,upnt);

lin_mat_swp=sortrows(lin_mat_swp,2);
lin_mat_swp;
upzone=zeros(size(fg));
midimg=fg;

grnimg=fg;                       %added for chandrabindu
for i=1:size(lin_mat_swp,1)
    row=lin_mat_swp(i,1);
    col=lin_mat_swp(i,2);  
    grnimg(row,col)=1;
end;                             %added....
% figure,imshow(grnimg)
% title('green')
for i=1:size(lin_mat_swp,1)
    row=lin_mat_swp(i,1);
    col=lin_mat_swp(i,2);

    
%     [r c]=find(fg(1:row-1,col)==1);  % previous version without matra
 [r c]=find(grnimg(1:row,col)==1); % new ver including matra
 if numel(r)~=0
     for k=1:numel(r)
         upzone(r(k),col)=1;
%          midimg(r(k),col)=0;    %%% added for deleting anything above line everything
     end;
 end;
 
end;
upzone=bwmorph(upzone,'bridge');
% figure,imshow(upzone)  %+++++++++
% title('org up zone');

[L n]=bwlabel(upzone);
midimg=fg;

val=  L(lin_mat_swp(1,1),lin_mat_swp(1,2));
n;
modfupzone=zeros(size(fg));
for i=1:n
 if val~=i
     index=find(L==i);    %remove disconn comp
     upzone(index)=0;modfupzone(index)=1;
     midimg(index)=0;
 end;
end;
% figure,imshow(upzone)
% title('up aftr remv disconn');
for i=1:size(lin_mat_swp,1)
    row=lin_mat_swp(i,1);      % remove matra
    col=lin_mat_swp(i,2);
    upzone(row,col)=0;
end;

[rw cw]=find(fg==1);
matra_row=hist_matra(fg);
ht_busy=round(matra_row-min(rw));

[L n]=bwlabel(upzone);
for i=1:n
    [r c]=find(L==i);
    mi=min(r);
    ma=max(r);
    index=find(L==i);
    if ma-mi<=(0.3*ht_busy)  %&& numel(index)<25        % subjected to image size give in percentage 
                                            % bankura images chandrabindu
        upzone(index)=0;
    else
        midimg(index)=0;
    end;
end;
modfupzone=modfupzone|upzone;
% figure,imshow(modfupzone)
% title('modf upper zone');
% figure,imshow(midimg)  %++++++++++++++
    
    