function [f]=busy(f)

if size(f,3)==4
    f=f(:,:,1:3);
end;

f=~im2bw(f);

[rw cw]=find(f==1);
f=f(min(rw):max(rw),min(cw):max(cw)); % trim image

f=padarray(f,[2 2]);  %% for letters which are touching the fisrst and last col of image
f=deskew(f);
% org=f;
% 
% 
% % fg=bwmorph(f,'thin',3); %wwwwwwwwww
% % fg=bwmorph(fg,'skel',inf);
% % 
% %  fg=bwmorph(fg,'spur',5);
% %  fg=bwmorph(fg,'clean');
% %  fg=bwmorph(fg,'bridge'); %wwwwwwwww
% fg=sgmnt_top(f); %% get the middle zone
% 
% [r c]=find(fg==1);
% wid=max(c)-min(c);
% l_dist=round(.175*wid);  %% note the val of this estimated letter width
% % matra_row=hist_matra(fg);
% 
% b_zoneimg=zeros(size(fg));
% 
% for i=1:max(r)
%     for j=1:size(fg,2)
%        jd=j+l_dist;
%        if jd>size(fg,2)
%            jd=size(fg,2);
%        end;
%         
%         if fg(i,j)==0
%             continue;
%         else
%             ind=find(fg(i,j+1:jd)==1);
%             if numel(ind)==0
%                 continue;
%             else
%                 b_zoneimg(i,j:j+ind(1)-1)=1;
%             end;
%         end;
%     end;
% end;
% 
% busy_hist_mat=zeros(1,size(fg,1));
% for i=1:size(b_zoneimg,1)
%      busy_hist_mat(i)=numel(find(b_zoneimg(i,:)==1));
% end;
% %% working fine
% 
%  maxpk=max(busy_hist_mat);               %%start --------
%  
%  [r1 c1]=find(busy_hist_mat~=0);
%  strt=min(c1)+round((max(c1)-min(c1))*.5);
%  
%  thrshld=maxpk*.25;         %% 0.3 of maximum peak in histogram
%  [r c]=find(busy_hist_mat(1,strt:max(c1))<=thrshld);
%      y=min(c)+strt-1 ; % remember what locations find() returns  %end----
%      
%      
%      
%    X=[1:size(f,2)];
%  
% % [maxpk ind]=max(busy_hist_mat);
% % thr=0.40*maxpk;
% % for i=ind:size(busy_hist_mat,2)
% % if busy_hist_mat(i)<thr
% % y=i;
% % break;
% % end;
% % end;
% 
% 
% 
%    busyimg=fg;
%    lzoneimg=fg(y+5:end,:);
%     busyimg(y+5:end,:)=0;  %% changed from +5
%     %% extract from original img
% %     if size(org,3)==4
% %     org=org(:,:,1:3);
% % end;
% %  
% % org=~im2bw(org);
% % org=padarray(org,[2 2]);
% % org=deskew(org);
% 
% busydil=imdilate(busyimg,strel('square',8));
% 
% orgbusy=~(org&busydil);
% %  imshow(orgbusy);
% %      imwrite(busyimg,'a1.bmp','bmp');  
%    
% %    figure,  plot(busy_hist_mat)     %+++++++++++++
% % figure,imshow(b_zoneimg),figure,imshow(busyimg),figure,imshow(orgbusy),
% % figure,imshow(fg)
% % hold on
% % plot(X,y)               % ++++++++++++++++++
% 
% 
% 
% 
% 
