   SourceDir='E:\Journal_Refine\Music\datashort\ImageTrain';%Give SOURCE FOLDER NAME
   TargetDir='E:\Journal_Refine\Music\runHMM\FeatureTrain';%Give TARGET FOLDER NAME
   mkdir(TargetDir);
 

Height = 240;
Width =40;
Gap=16;
[Files,Bytes,Names] = DIRR(SourceDir,'name');
[~,length] = size(Names);
count = 1;
  for n = 1:length
    ImgName=Names(n);
    [pathstr, name, ext] = fileparts(ImgName{1});
    
    FeaName=strcat(TargetDir, '\', name, '.fea')
    disp(count);
    count = count + 1;
    
    im = imread(char( Names(n)) );  
    im2=im;
     
     
%%%%%%This part is for pre-defined height %%%
    [H W] = size(im2);
    if H ~= Height
        H1 = Height;
        W1 = round(Height*W/H);
        im2 = imresize(im2, [H1 W1]);
    end     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [H W] = size(im2);
    Pad = Gap - rem(W-Width, Gap);
    im2 = padarray(im2, [0 Pad], 256, 'post');
    im2 = padarray(im2, [5 5], 256);
    if(size(im2,3)==3)
        im2=double(rgb2gray(im2))/255;
    end
%     im2 = filter2(fspecial('gaussian', 7, 2.5),im2); 
    [H W] = size(im2);
    im2 = imcrop(im2, [6, 6, W-11, H-11]);
    [H W] = size(im2);
    K = im2;
    Temp = mat2gray(K); %imshow(Temp)
    div= (W-Width)/Gap;
 
    
    % % % % 
    [meanAmplitude, msEnergy] = gaborWavelet(Temp,10,8); % 4 = number of scales, 6 = number of orientations
%          wavelet_moments = waveletTransform(P);        
     meanAmplitude = meanAmplitude/norm(meanAmplitude);
     msEnergy =msEnergy/norm(msEnergy) ;
         
    %%%%%%%HOG_GROD%%%%%%%%%%%
    Feature = [];
    for i = 1:div
        P = Temp(:, i*Gap +1:i*Gap +1 + Width -1); %imshow(P) 
        H = [meanAmplitude,msEnergy];
        Feature = [Feature; H];
    end
    
    writehtk(FeaName, Feature, 10E-3, 9);
%     
%%%%%%%%%%%%%%%Narti Bunk%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          
%          for i = 0:div
%                  P = Temp(:, i*Gap +1:i*Gap +1 + Width -1); %imshow(P) 
%                  Hi = MB_Feature(im2bw(P));
%                  [rr cc]=size(Hi);
%                  cnt_p=1;
%                  Feature = [];
%                   for m=1:rr
%                              for w=1:cc
%                                Feature(1,cnt_p)=  Hi(m,w);
%                                cnt_p=cnt_p+1;
%                               %fprintf(fid,'%e ', H(m,w));
%                              end
%                              
%                            %fprintf(fid, '\n');
%                   end
%          end
%           writehtk(FeaName, Feature, 10E-3, 9);
 
end