imagefolder = 'E:\experiments\ImageTest_Zoned';
featurefolder = 'E:\experiments\ImageTest_Zoned_Feature_CCV';

imgList = dir([imagefolder, '\*.tif']);

for i = 1:numel(imgList)
    fname = imgList(i).name;
    thefilename = [imagefolder, '\', fname];
    disp(thefilename);
    F = norm_vector(get_img_feature(thefilename, 0));
    [~, n, ~] = fileparts(thefilename);
     writehtk([featurefolder,'\',n,'.fea'], F, 10E-3, 9);
end