
SourceDir = 'E:\Journal_Refine\Music\datashort\ImageTrain';
TargetDir = 'E:\Journal_Refine\Music\runHMM\FeatureTrain';

  mkdir(TargetDir);
[Files,Bytes,Names] = DIRR(SourceDir,'name');
for n = 1: numel(Names)
    ImgName=Names{n};
    [pathstr, name, ext] = fileparts(ImgName);
%     FeaName=strcat(TargetDir, '\', name, '.fea');
%     fid=fopen(FeaName, 'w');
    
    F = get_img_feature(ImgName, 0);
    FeaFileName = strcat(TargetDir, '\', name, '.fea')
    writehtk(FeaFileName,F,10E-3,9);
    
%     for(i=1:size(F,1))
%         if(i ==1) 
%             D = F(i,:); A = F(i,:);
%         elseif(i==2)
%             D = F(i,:) - F(i-1,:); A = F(i,:) - F(i-1,:);
%         else 
%             D = F(i,:) - F(i-1,:); A = F(i,:) - 2*F(i-1,:) + F(i-2,:);            
%         end        
%         fprintf(fid,' %f %f %f ', F(i,:), D, A);
%         fprintf(fid, '\n');
%     end
%     fclose(fid);
end