function [ F ] = norm_vector( F )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

maxims = max(F);

for i = 1:size(F,2)
    for j = 1:size(F,1)
        F(j,i) = F(j,i)/maxims(1,i);
    end
end

end

