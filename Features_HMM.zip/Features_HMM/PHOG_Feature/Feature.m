
SourceDir = 'C:\Users\Spider\Desktop\F\SMALL_DATASET\MID_IMG\*.tif';
TargetDir = 'C:\Users\Spider\Desktop\F\SMALL_DATASET\MID_FEA\';

mkdir TargetDir;
[Files,Bytes,Names] = DIRR(SourceDir,'name');
[~,length]=size(Names);
for n = 1: length
    ImgName=Names(n);
    [pathstr, name, ext] = fileparts(ImgName{1});
    FeaName=strcat(TargetDir, name, '.fea');
    
    F = img_LGH_feature(ImgName{1});
    writehtk(FeaName, F, 10E-3, 9);
    disp([name,'.fea']);
end