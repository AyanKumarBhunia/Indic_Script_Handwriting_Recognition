function [upPr ] = UpperProfile(im )
%UPPERPROFILE Summary of this function goes here
%   Detailed explanation goes here
bw=im2bw(im);
[m, n]=size(im);
upPr=ones(1,n);
for i=1:n
   %upPr(i)=m-
   x=find(bw(:,i)==0,1,'first');
   if x~=0
       upPr(i)=m-x;
   else upPr(i)=m;
   end
  %j=0;
  %while(j!=0&&j<=m)
      
end
upPr=upPr/size(im,1);
end

