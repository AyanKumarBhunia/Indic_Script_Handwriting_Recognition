function [ dif ] = DifferenceOfLowUp(im )
%DIFFERENCEOFLOWUP Summary of this function goes here
%   Detailed explanation goes here
dif=UpperProfile(im)-LowerProfile(im);

end

