function [proj ] = projection( I )
%PROJECTION Summary of this function goes here
%   Detailed explanation goes here
    I=im2bw(I);
    I = imcomplement(I);
    proj=sum(I,1);
    proj=proj/size(I,1);
end

