function [mean] = MeanProfile( im )
%MEANPROFILE Summary of this function goes here
%   Detailed explanation goes here
im = im2bw(im);
[m, n]=size(im);
mean=zeros(1,n);
for j=1:n
    sum=0;
    count=0;
    for i=1:m
        if(im(i,j)==0)
            count=count+1;
            sum=sum+m-i-1;
        end
        if count~=0
            mean(j)=sum/count;
            mean(j)=mean(j)/m;
        else
            mean(j)=0;
        end
    end
% mean=zeros(n);
end
