function [lowPr ] = LowerProfile(im )
%UPPERPROFILE Summary of this function goes here
%   Detailed explanation goes here
bw=im2bw(im);
[m, n]=size(im);
lowPr=zeros(1,n);
for i=1:n
    %lowPr(i)=m-
    x=find(bw(:,i)==0,1,'last');
    if x~=0
        lowPr(i)=m-x;
    else
        lowPr(i)=m;
    end
end
lowPr=lowPr/m;
end

