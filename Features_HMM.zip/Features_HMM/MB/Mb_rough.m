 

%function [ppr_data]=HOG_Rod(SourceDir, TargetDir) 
% HOG_Rod('src\*', 'tgt')
SourceDir='D:\Datasets\DATA\DATA\TestZoned'; 
TargetDir='D:\New folder';

Height = 60; 
Width = 10;
Gap=3;
 
[Files,Bytes,Names] = DIRR(SourceDir,'name');
for n = 1:length(Names)
    ImgName=Names(n);
    [pathstr, name, ext] = fileparts(ImgName{1});
    %FeaName=strcat(TargetDir, '\', name, '.LGH')
    FeaName=strcat(TargetDir, '\', name, '.fea')
    
    im = imread(char( Names(n)) );  
    im2 = im;
    
%%%%%%This part is for pre-defined height %%%
    [H W] = size(im2);
    if H ~= Height
        H1 = Height;
        W1 = round(Height*W/H);
        im2 = imresize(im2, [H1 W1]);
    end     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [H W] = size(im2);
    Pad = Gap - rem(W-Width, Gap);
    im2 = padarray(im2, [0 Pad], 256, 'post');
    im2 = padarray(im2, [5 5], 256);
    if(size(im2,3)==3)
        im2=rgb2gray(im2);
    end
%     im2 = filter2(fspecial('gaussian', 7, 2.5),im2);
    
    [H W] = size(im2);
    im2 = imcrop(im2, [6, 6, W-11, H-11]);
    %im2 = 255-im2;
    [H W] = size(im2);
    K = im2;
    Temp = mat2gray(K); %imshow(Temp)
    div= (W-Width)/Gap;
    
    %%%%%%%HOG_GROD%%%%%%%%%%%
    Feature = [];
    for i = 0:div
        P = Temp(:, i*Gap +1:i*Gap +1 + Width -1); %imshow(P)
        H = MB_Feature(P);
        
%         H = HOG(P, 4, 4, 8);
         M = max(H);
         if(M ~= 0) 
             H = H/M;
         end
        
        
        Feature = [Feature; H];
    end
    writehtk(FeaName, Feature, 10E-3, 9);
%%%%%%%%%%%%%%%Narti Bunk%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          
%          for i = 0:div
%                  P = Temp(:, i*Gap +1:i*Gap +1 + Width -1); %imshow(P) 
%                  Hi = MB_Feature(im2bw(P));
%                  [rr cc]=size(Hi);
%                  cnt_p=1;
%                  Feature = [];
%                   for m=1:rr
%                              for w=1:cc
%                                Feature(1,cnt_p)=  Hi(m,w);
%                                cnt_p=cnt_p+1;
%                               %fprintf(fid,'%e ', H(m,w));
%                              end
%                              
%                            %fprintf(fid, '\n');
%                   end
%          end
%           writehtk(FeaName, Feature, 10E-3, 9);
 
  end