%function [ppr_data]=HOG_Rod(SourceDir, TargetDir) 
% HOG_Rod('src\*', 'tgt')
SourceDir='D:\Datasets\DATA\DATA\TestZoned'; 
TargetDir='D:\New folder';

Height = 60; 
Width = 10;
Gap=3;
 
[Files,Bytes,Names] = DIRR(SourceDir,'name');
for n = 1:length(Names)
    ImgName=Names(n);
    [pathstr, name, ext] = fileparts(ImgName{1});    
    FeaName=strcat(TargetDir, '\', name, '.fea')   
    im = imread(char( Names(n)) );  
    im2 = im;
    
%%%%%%This part is for pre-defined height %%%
    [H W] = size(im2);
    if H ~= Height
        H1 = Height;
        W1 = round(Height*W/H);
        im2 = imresize(im2, [H1 W1]);
    end     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [H W] = size(im2);
    Pad = Gap - rem(W-Width, Gap);
    im2 = padarray(im2, [0 Pad], 256, 'post');
    im2 = padarray(im2, [5 5], 256);
    if(size(im2,3)==3)
        im2=rgb2gray(im2);
    end
 
    
    %%%%%%%HOG_GROD%%%%%%%%%%%
    Feature = MB_Feature2(im2);
   
    writehtk(FeaName, Feature, 10E-3, 9);
%%%%%%%%%%%%%%%Narti Bunk%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          
 
  end