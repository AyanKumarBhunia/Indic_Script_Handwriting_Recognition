function [ trans ] = Transition( im )
%TRANSITION Summary of this function goes here
%   Detailed explanation goes here
bw=im2bw(im);
m=size(bw,1);
n=size(bw,2);
trans=zeros(1,n);
    for i=1:n
        prev=bw(1,i);
        for j=2:m
            cur=bw(j,i);
            if(prev==1&&cur==0)
                trans(i)=trans(i)+1;
            end
            prev=cur;
        end
    end
 trans=trans/4;
end

