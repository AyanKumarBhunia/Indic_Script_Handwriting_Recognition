function [ F ] = MB_Feature( im )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
F1 = projection(im);
F2 = Transition(im);
F3 = UpperProfile(im);
F4 = LowerProfile(im);
F5 = DifferenceOfLowUp(im);
F6 = [0 diff(F3)];
F6 = [0+(((F6-(-1))/(1-(-1)))*(1-0))];
F7 = [0 diff(F4)];
F7 = 0+(((F7-(-1))/(1-(-1)))*(1-0));
F8 = MeanProfile(im);
F9 = StdDev(im);
F = [F1', F2', F3', F4', F5', F6', F7', F8', F9'];
end

