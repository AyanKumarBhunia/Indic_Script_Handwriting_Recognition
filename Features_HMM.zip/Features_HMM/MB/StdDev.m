function [ dev ] = StdDev( im )
%STDDEV Summary of this function goes here
%   Detailed explanation goes here
[m, ~] = size(im);
dev=std(single(im),0,1);
dev=dev/m;
end

